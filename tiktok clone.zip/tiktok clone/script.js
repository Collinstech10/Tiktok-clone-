const videos = ['videos/video1.mp4', 'videos/video2.mp4'];
const container = document.getElementById('video-feed');
const uploadInput = document.getElementById('upload');

function createVideoElement(src) {
  const wrapper = document.createElement('div');
  wrapper.className = 'w-full max-w-sm bg-black rounded-xl shadow-lg';

  const video = document.createElement('video');
  video.src = src;
  video.controls = true;
  video.className = 'w-full rounded-t-xl';

  const likeButton = document.createElement('button');
  likeButton.textContent = '❤️ Like (0)';
  likeButton.className = 'w-full py-2 bg-red-500 text-white font-bold rounded-b-xl';
  let count = 0;
  likeButton.addEventListener('click', () => {
    count++;
    likeButton.textContent = `❤️ Like (${count})`;
  });

  wrapper.appendChild(video);
  wrapper.appendChild(likeButton);
  return wrapper;
}

// Load default videos
videos.forEach(v => container.appendChild(createVideoElement(v)));

// Handle Upload
uploadInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const url = URL.createObjectURL(file);
  container.prepend(createVideoElement(url));
});